
package com.mycompany.restaurante;

public abstract class ItemCardapio {
    private String nome;
    private double preco;

    public ItemCardapio(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public abstract double calcularPrecoFinal(); //quero declarar um metodo, meu filho que vai declarar as carcateristicas
    
    public String ExibirItem (){
        return "Seu cálculo final é de: " + calcularPrecoFinal(); //esse tem o codigo "caracteristicas" porque é só pra essa classe
    }
    
    // void é utilizado em metodo que não precisa de retorno
}
