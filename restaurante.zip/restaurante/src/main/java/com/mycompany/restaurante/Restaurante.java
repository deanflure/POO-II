

package com.mycompany.restaurante;

public class Restaurante {

    public static void main(String[] args) {
        
        Comanda comanda1 = new Comanda ("Mesa 8");
        
        ItemCardapio item1 = new PratoPrincipal("Miojo", 3.00);
        ItemCardapio item2 = new Bebida("Chopp", 15.00);
        
        try{
            comanda1.AdicionarItem(item1);
            comanda1.AdicionarItem(item2);
        }catch (ItemIndisponivelException ex){
            System.out.println("Erro item indisponivel");
        }
        
        for(ItemCardapio item : comanda1.getItens()){
            System.out.println(item.ExibirItem());
        }
        System.out.println("Total: R$ " + comanda1.getFatura().getValorTotal());
    }
}
