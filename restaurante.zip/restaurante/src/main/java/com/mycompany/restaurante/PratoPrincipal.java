
package com.mycompany.restaurante;

public class PratoPrincipal extends ItemCardapio {

    public PratoPrincipal(String nome, double preco) {
        super(nome, preco);//super pois está apontando da classe pai
    }
    
    @Override
    public double calcularPrecoFinal(){
        return getPreco() * 1.10; //taxa de 10%
    }
    
}
