
package com.mycompany.restaurante;

public class Fatura {
    
    private double valorTotal = 0;
    
    public void adicionarValor(double valor){
        if(valor < 0){
            throw new ValorInvalidoException("Valor invalido na fatura");//se o valor foi menor que zero ele tem que aparecer o erro
        }
        this.valorTotal = this.valorTotal + valor; 
    }
    
    public double getValorTotal(){
        return valorTotal;
    }
}
