
package com.mycompany.restaurante;

public interface Cancelavel { //interface só pode metodo abstrato
    void cancelar(); //está vazio pq ele está me obrigando a criar um codigo na classe que tenha itens pra cancelar
}
