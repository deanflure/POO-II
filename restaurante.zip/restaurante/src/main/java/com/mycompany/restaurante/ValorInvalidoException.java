
package com.mycompany.restaurante;

public class ValorInvalidoException extends RuntimeException {

    public ValorInvalidoException(String message) {
        super(message);
    }
    
}
