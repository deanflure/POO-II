
package com.mycompany.restaurante;

import java.util.ArrayList;
import java.util.List;

public class Comanda implements Cancelavel{//botão na lampada pra implementar os abstract
    
    private int limiteItem = 10;
    
    private String mesa;// uma parte que pertence ao todo que é o itemcardapio // assosiação
    private List<ItemCardapio> itens = new ArrayList();//cltr space para importar as listas // estamos fazendo uma agregação
    private Fatura fatura;
    private boolean cancelada;
    
    public Comanda (String mesa){
        this.mesa = mesa;
        this.fatura = new Fatura();//composição, acaso a fatura deixe de existir, a fatura tbm deixa
        
    }
    public void AdicionarItem(ItemCardapio itemcardapio) throws ItemIndisponivelException{
         if (itens.size()> limiteItem){
             throw new ItemIndisponivelException("O liteme de itens foi ultrpassado");
         }
         itens.add(itemcardapio);
         fatura.adicionarValor(itemcardapio.calcularPrecoFinal());
    }

    public int getLimiteItem() {
        return limiteItem;
    }

    public void setLimiteItem(int limiteItem) {
        this.limiteItem = limiteItem;
    }

    public String getMesa() {
        return mesa;
    }

    public void setMesa(String mesa) {
        this.mesa = mesa;
    }

    public List<ItemCardapio> getItens() {
        return itens;
    }

    public void setItens(List<ItemCardapio> itens) {
        this.itens = itens;
    }

    public Fatura getFatura() {
        return fatura;
    }

    public void setFatura(Fatura fatura) {
        this.fatura = fatura;
    }

    public boolean isCancelada() {
        return cancelada;
    }

    public void setCancelada(boolean cancelada) {
        this.cancelada = cancelada;
    } 

    @Override
    public void cancelar() { 
        this.cancelada = true;
    }
}
         
    
