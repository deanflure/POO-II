package com.mycompany.restaurante;


public class ItemIndisponivelException extends Exception{

    public ItemIndisponivelException(String message) {
        super(message);
    }    
}
