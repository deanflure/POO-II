
package com.mycompany.conteudo;

public abstract class Conteudo {

    private String titulo;
    private int duracaoMinutos;

    public Conteudo(String titulo, int duracaoMinutos) {
        this.titulo = titulo;
        this.duracaoMinutos = duracaoMinutos;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getDuracaoMinutos() {
        return duracaoMinutos;
    }

    public abstract double calcularPontuacao();

    public void exibirFicha() {
        System.out.println("Título: " + titulo);
        System.out.println("Duração: " + duracaoMinutos + " minutos");
        System.out.println("Pontuação: " + calcularPontuacao());
        System.out.println("-------------------------");
    }
}
//2
public class Filme extends Conteudo {

    private int numeroAvaliacoes;

    public Filme(String titulo, int duracaoMinutos, int numeroAvaliacoes) {
        super(titulo, duracaoMinutos);
        this.numeroAvaliacoes = numeroAvaliacoes;
    }

    @Override
    public double calcularPontuacao() {
        return 8.0 + (numeroAvaliacoes * 0.1);
    }
}
//3
public class Serie extends Conteudo {

    private int numeroTemporadas;

    public Serie(String titulo, int duracaoMinutos, int numeroTemporadas) {
        super(titulo, duracaoMinutos);
        this.numeroTemporadas = numeroTemporadas;
    }

    @Override
    public double calcularPontuacao() {
        return 7.0 + (numeroTemporadas * 0.5);
    }
}
//4
public interface Bloqueavel {

    void bloquear();
}
//5
public class LimiteFavoritosExcedidoException extends Exception {

    public LimiteFavoritosExcedidoException(String mensagem) {
        super(mensagem);
    }
}
//6
public class TempoInvalidoException extends RuntimeException {

    public TempoInvalidoException(String mensagem) {
        super(mensagem);
    }
}
//7
public class HistoricoVisualizacao {

    private int totalMinutosAssistidos;

    public HistoricoVisualizacao() {
        totalMinutosAssistidos = 0;
    }

    public void registrarVisualizacao(int minutos) {

        if (minutos <= 0) {
            throw new TempoInvalidoException(
                "O tempo de visualização deve ser maior que zero."
            );
        }

        totalMinutosAssistidos += minutos;
    }

    public int getTotalMinutosAssistidos() {
        return totalMinutosAssistidos;
    }
}
//8
import java.util.ArrayList;
import java.util.List;

public class PerfilUsuario implements Bloqueavel {

    private List<Conteudo> favoritos;
    private final int limiteFavoritos = 3;

    // Composição
    private HistoricoVisualizacao historico;

    private boolean bloqueado;

    public PerfilUsuario() {
        favoritos = new ArrayList<>();

        // O próprio PerfilUsuario cria seu histórico
        historico = new HistoricoVisualizacao();

        bloqueado = false;
    }

    // Agregação
    public void adicionarFavorito(Conteudo c)
            throws LimiteFavoritosExcedidoException {

        if (favoritos.size() >= limiteFavoritos) {
            throw new LimiteFavoritosExcedidoException(
                "Limite máximo de favoritos atingido: "
                + limiteFavoritos
            );
        }

        favoritos.add(c);
    }

    public HistoricoVisualizacao getHistorico() {
        return historico;
    }

    public List<Conteudo> getFavoritos() {
        return favoritos;
    }

    public boolean isBloqueado() {
        return bloqueado;
    }

    @Override
    public void bloquear() {
        bloqueado = true;
    }
}
//9
public class TesteStreaming {

    public static void main(String[] args) {

        // ==========================================
        // CRIAÇÃO DOS CONTEÚDOS
        // ==========================================

        Filme filme = new Filme(
            "Interestelar",
            169,
            5
        );

        Serie serie = new Serie(
            "Stranger Things",
            50,
            4
        );

        Filme filme2 = new Filme(
            "O Senhor dos Anéis",
            178,
            3
        );

        Filme filme3 = new Filme(
            "Matrix",
            136,
            4
        );


        // ==========================================
        // CRIAÇÃO DO PERFIL
        // ==========================================

        PerfilUsuario perfil = new PerfilUsuario();


        // ==========================================
        // AGREGAÇÃO E POLIMORFISMO
        // ==========================================

        try {

            perfil.adicionarFavorito(filme);
            perfil.adicionarFavorito(serie);
            perfil.adicionarFavorito(filme2);

        } catch (LimiteFavoritosExcedidoException e) {

            System.out.println("Erro: " + e.getMessage());
        }


        // ==========================================
        // EXIBINDO OS FAVORITOS
        // ==========================================

        System.out.println("=== FAVORITOS ===");

        for (Conteudo conteudo : perfil.getFavoritos()) {

            // Polimorfismo:
            // cada objeto executa sua própria versão
            // de calcularPontuacao()
            conteudo.exibirFicha();
        }


        // ==========================================
        // EXCEÇÃO DE LIMITE DE FAVORITOS
        // ==========================================

        System.out.println("=== TESTANDO LIMITE ===");

        try {

            // O limite é 3 e já existem 3 favoritos
            perfil.adicionarFavorito(filme3);

        } catch (LimiteFavoritosExcedidoException e) {

            System.out.println(
                "Exceção tratada: " + e.getMessage()
            );
        }


        // ==========================================
        // COMPOSIÇÃO - HISTÓRICO
        // ==========================================

        System.out.println("\n=== HISTÓRICO ===");

        perfil.getHistorico().registrarVisualizacao(120);
        perfil.getHistorico().registrarVisualizacao(60);

        System.out.println(
            "Total de minutos assistidos: "
            + perfil.getHistorico().getTotalMinutosAssistidos()
        );


        // ==========================================
        // EXCEÇÃO DE TEMPO INVÁLIDO
        // ==========================================

        System.out.println("\n=== TESTANDO TEMPO INVÁLIDO ===");

        try {

            perfil.getHistorico().registrarVisualizacao(-10);

        } catch (TempoInvalidoException e) {

            System.out.println(
                "Exceção tratada: " + e.getMessage()
            );
        }


        // ==========================================
        // INTERFACE BLOQUEAVEL
        // ==========================================

        System.out.println("\n=== BLOQUEIO DO PERFIL ===");

        System.out.println(
            "Perfil bloqueado antes: "
            + perfil.isBloqueado()
        );

        perfil.bloquear();

        System.out.println(
            "Perfil bloqueado depois: "
            + perfil.isBloqueado()
        );
    }
}